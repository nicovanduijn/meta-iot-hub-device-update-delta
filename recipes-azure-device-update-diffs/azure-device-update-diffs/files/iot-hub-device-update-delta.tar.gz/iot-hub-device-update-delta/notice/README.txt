The NOTICE.txt file in this directory pertains to open source used in this project. 
The code for these components is compiled via VCPKG and is not included in this repo.

The overlay port for e2fsprogs includes a custom .patch file for a small modification to the code of
e2fsprogs and this is included in this repo.