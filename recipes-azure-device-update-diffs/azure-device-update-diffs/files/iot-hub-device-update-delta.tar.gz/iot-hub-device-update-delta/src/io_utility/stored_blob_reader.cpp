/**
 * @file stored_blob_reader.cpp
 *
 * @copyright Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 */
#include "stored_blob_reader.h"

#include <cstring>
