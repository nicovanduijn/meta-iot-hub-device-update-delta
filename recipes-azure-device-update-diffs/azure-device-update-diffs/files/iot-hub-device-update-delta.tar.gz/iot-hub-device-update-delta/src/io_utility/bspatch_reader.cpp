/**
 * @file bspatch_reader.cpp
 *
 * @copyright Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 */
#include "bspatch_reader.h"

// io_utility::bspatch_decompression_reader::bspatch_decompression_reader(
//	reader *basis, uint64_t basis_size, reader *delta, uint64_t delta_size)
//{}