/**
 * @file stored_blob_reader_factory.cpp
 *
 * @copyright Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 */
#include "reader.h"
#include "stored_blob_reader_factory.h"
#include "stored_blob_reader.h"
