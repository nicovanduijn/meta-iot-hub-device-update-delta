/**
 * @file file_details.cpp
 *
 * @copyright Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 */
#include "file_details.h"
#include "hash_utility.h"
